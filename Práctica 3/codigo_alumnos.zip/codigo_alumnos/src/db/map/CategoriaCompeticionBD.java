package db.map;

import model.CategoriaCompeticion;

public class CategoriaCompeticionBD {
	/**
	 * 
	 * @param categoriaCompeticion
	 * @return Obtiene de la base de datos la categor�a de competici�n con id igual al par�metro categoriaCompeticion, 
	 *    creando un objeto del tipo model.CategoriaCompeticion
	 */
	public static CategoriaCompeticion getById(int categoriaCompeticion) {
		// TODO: Implementar
		return null;
	}
}
